/******************
初期化(変数letで宣言)
******************/
let canvas_mouse_event = false; //スイッチ [ true=線を引く, false=線は引かない ]  ＊＊＊
let canvas_mouse_rect = false;
let canvas_mouse_arc = false;
let canvas_mouse_img = false;
let canvas_mouse_text = false;
let oldX = 0;           //１つ前の座標を代入するための変数
let oldY = 0;           //１つ前の座標を代入するための変数
let bold_line = 3;      //ラインの太さをここで指定
let linecolor = "#ccc";  //ラインの色をここで指定
let fillcolor = "#f00";  //面の色をここで指定
let rectVertcal = "1";   //四角高さをここで指定
let rectWide = "1";      //四角横をここで指定
let arcSize = "1"; //円を描写
let font


/*--------------------------------
色の変更を反映
--------------------------------*/
//線
$("#linecolor").on("change",function(){
    linecolor = $(this/*=#color 今選択したもの*/).val();//色の取得
});
//面
$("#fillcolor").on("change",function(){
    fillcolor = $(this/*=#color 今選択したもの*/).val();//色の取得
});

/*--------------------------------
線の太さを反映
---------------------------------*/
$("#range").on("change",function(){
    bold_line = $(this).val();
});


/*-------------------------------
フリーハンド
--------------------------------*/
const can = $("#drowarea")[0]; //CanvasElement
const ctx = can.getContext("2d"); //描画するための準備！

//mouseup：フラグをfalse
$(can).on("mouseup",function(){
    canvas_mouse_event=false;
});

//キャンバスから離れると描写しない
$(can).on("mouseout",function(){
    canvas_mouse_event=false;
});

//描写
$(can).on("mousedown",function(e){
    console.log(e);
    oldX = e.offsetX; //現在地点XをoldXに代入
    oldY = e.offsetY; //現在地点YをoldYに代入
    canvas_mouse_event = true; //書くぞー！！
});

//mousemoveイベント
$(can).on("mousemove",function(e){
    if(canvas_mouse_event==true){
        const px = e.offsetX; //現在地点x
        const py = e.offsetY; //現在地点y
        ctx.strokeStyle = linecolor;//線の色y
        ctx.lineWidth = bold_line;//線の太さ
        ctx.beginPath();//現在のパスをリセット
        ctx.lineJoin= "round";//線の接合箇所の//
        ctx.lineCap = "round";//線端の//
        ctx.moveTo(oldX, oldY);//新しいサブパスの開始点を座標
        ctx.lineTo(px, py);
        ctx.stroke();
        oldX = px; //入れ替え
        oldY = py; //入れ替え
    }
});


/*-----------------------------------------
四角を生成
-----------------------------------------*/
const rect = $("#drowarea")[0];//CanvasElement
const rect1 = rect.getContext("2d");//描画するための準備！

//四角の数値を反映
//高さ
$("#rectVertcal").on("change",function(){
    rectVertcal = $(this).val();
});
//幅
$("#rectWide").on("change",function(){
    rectWide = $(this).val();
});

//キャンバスから離れると描写しない
$(rect).on("mouseout",function(){
    canvas_mouse_rect=false;
});

//mouseup：フラグをfalse
$(rect).on("mouseup",function(){
    canvas_mouse_rect=false;
});

//描写
$("#rect").on("click",function(){
    console.log();
    canvas_mouse_rect = true;
});

//mousemoveイベント
$("#rect").on("click",function(){
    if(canvas_mouse_rect==true){
        rect1.strokeStyle = linecolor;
        rect1.fillStyle = fillcolor;//塗色
        rect1.lineWidth = bold_line;
        rect1.beginPath();//x=0 y=0
        rect1.moveTo(oldX, oldY);
        rect1.stroke();
        rect1.rect(oldX-rectWide/2, oldY-rectVertcal/2, rectWide, rectVertcal);//横、縦、横幅、縦幅
        rect1.fill();
        rect1.stroke();
        //oldX = px; //入れ替え
        //oldY = py; //入れ替え
    }
    // alert("ok")
});


/*------------------------------------
円を生成
------------------------------------*/
const arc = $("#drowarea")[0];//CanvasElement
const arc1 = arc.getContext("2d"); //描画するための準備！

//円の数値を反映
$("#arcSize").on("change",function(){
    arcSize = $(this).val();
});

//キャンバスから離れると描写しない
$(arc).on("mouseout",function(){
    canvas_mouse_arc=false;
});

//mouseup：フラグをfalse
$(arc).on("mouseup",function(){
    canvas_mouse_arc=false;
});

//描写
$("#arc").on("click",function(){
    console.log();
    canvas_mouse_arc = true;
});

//mousemoveイベント
$("#arc").on("click",function(){
    if(canvas_mouse_arc==true){
        arc1.strokeStyle = linecolor;
        arc1.fillStyle = fillcolor;//塗色
        arc1.lineWidth = bold_line;
        arc1.beginPath();//x=0 y=0 パスの開始
        arc1.arc(oldX, oldY, arcSize, 0, Math.PI * 2.0, false/*trueと半円*/); // full circle 丸は起点が中心
        arc1.fill();
        arc1.stroke();
        alert("arc")
    }
});
/*----------------------------------------
直線を生成
----------------------------------------*/
/*----------------------------------------
画像生成
----------------------------------------*/

var file = document.getElementById('file');
var canvas = document.getElementById('drowarea');
var canvasWidth = 100;
var canvasHeight = 50;
var uploadImgSrc;

// Canvasの準備
//canvas.width = canvasWidth;
//canvas.height = canvasHeight;
var image = canvas.getContext('2d');

//描写
function loadLocalImage(e){
  // ファイル情報を取得
    var fileData = e.target.files[0];

  // 画像ファイル以外は処理を止める
    if(!fileData.type.match('image.*')) {
    alert('画像を選択してください');
    return;
    }

  // FileReaderオブジェクトを使ってファイル読み込み
    var reader = new FileReader();
  // ファイル読み込みに成功したときの処理
    reader.onload = function() {
    // Canvas上に表示する
    uploadImgSrc = reader.result;
    canvasDraw();
    }
  // ファイル読み込みを実行
    reader.readAsDataURL(fileData);

}
// ファイルが指定された時にloadLocalImage()を実行
file.addEventListener('change', loadLocalImage, false);

// Canvas上に画像を表示する
function canvasDraw() {
  // canvas内の要素をクリアする
    image.clearRect(0, 0, canvasWidth, canvasHeight);

  // Canvas上に画像を表示
    var img = new Image();
    img.src = uploadImgSrc;
    img.onload = function() {
    image.drawImage(img, 0, 0, canvasWidth, this.height * (canvasWidth / this.width));
    }
}


/*----------------------------------------
テキスト生成
----------------------------------------*/
const text = $("#drowarea")[0];//CanvasElement
const text1 = text.getContext("2d"); //描画するための準備！

//文章
$("#text").on("change",function(){
    text2 = $(this).val();
});
//フォントサイズ
$("#fontSize").on("change",function(){
    font1 = $(this).val();
});
//フォント
$("#font").on("change",function(){
    font2 = $(this).val();
});

//描写
$("#comment").on("click",function(){
    console.log();
    canvas_mouse_text = true;
});

//mousemoveイベント
$("#comment").on("click",function(){
    if(canvas_mouse_text==true){
        text1.fillStyle = fillcolor;//塗色
        text1.beginPath();//x=0 y=0
        text1.moveTo(oldX, oldY);
        text1.font="50px serif";//サイズとフォント 変更できるようにしたい
        text1.fillText(text2, oldX, oldY,); 
        text1.fill();
        text1.stroke;
        alert(OK);
    }
});




/******************
ドラッグ＆ドロップ移動 ツールのみ
******************/
(function(){

    //要素の取得
    var elements = document.getElementsByClassName("drag-and-drop");

    //要素内のクリックされた位置を取得するグローバル（のような）変数
    var x;
    var y;

    //マウスが要素内で押されたとき、又はタッチされたとき発火
    for(var i = 0; i < elements.length; i++) {
        elements[i].addEventListener("mousedown", mdown, false);
        elements[i].addEventListener("touchstart", mdown, false);
    }

    //マウスが押された際の関数
    function mdown(e) {

        //クラス名に .drag を追加
        this.classList.add("drag");

        //タッチデイベントとマウスのイベントの差異を吸収
        if(e.type === "mousedown") {
            var event = e;
        } else {
            var event = e.changedTouches[0];
        }

        //要素内の相対座標を取得
        x = event.pageX - this.offsetLeft;
        y = event.pageY - this.offsetTop;

        //ムーブイベントにコールバック
        document.body.addEventListener("mousemove", mmove, false);
        document.body.addEventListener("touchmove", mmove, false);
    }

    //マウスカーソルが動いたときに発火
    function mmove(e) {

        //ドラッグしている要素を取得
        var drag = document.getElementsByClassName("drag")[0];

        //同様にマウスとタッチの差異を吸収
        if(e.type === "mousemove") {
            var event = e;
        } else {
            var event = e.changedTouches[0];
        }

        //フリックしたときに画面を動かさないようにデフォルト動作を抑制
        e.preventDefault();

        //マウスが動いた場所に要素を動かす
        drag.style.top = event.pageY - y + "px";
        drag.style.left = event.pageX - x + "px";

        //マウスボタンが離されたとき、またはカーソルが外れたとき発火
        drag.addEventListener("mouseup", mup, false);
        document.body.addEventListener("mouseleave", mup, false);
        drag.addEventListener("touchend", mup, false);
        document.body.addEventListener("touchleave", mup, false);

    }

    //マウスボタンが上がったら発火
    function mup(e) {
        var drag = document.getElementsByClassName("drag")[0];

        //ムーブベントハンドラの消去
        document.body.removeEventListener("mousemove", mmove, false);
        //drag.removeEventListener("mouseup", mup, false);
        document.body.removeEventListener("touchmove", mmove, false);
        drag.removeEventListener("touchend", mup, false);
        //クラス名 .drag も消す
        drag.classList.remove("drag");
    }

})()

/******************
#clear_btn：クリアーボタンAction

ctx.beginPath();
ctx.clearRect(0, 0, can.width, can.height);
******************/
$("#clear_btn").on("click",function(){
    ctx.beginPath();
    ctx.clearRect(0,0,can.width, can.height);//消しゴム機能はこの文を応用する
    arc1.beginPath();
    arc1.clearRect(0,0,can.width, can.height);
    alert("OK");
});

/*----------------------------------------
fabric ※出来ず
----------------------------------------*/

/*----------------------------------------
ドラッグ操作
----------------------------------------*/
var canvas = document.getElementById("drowarea");
        var context = canvas.getContext('2d');
        var objX, objY;
        var objWidth, objHeight;

        function init() {
        // オブジェクトの大きさを定義
        objWidth = 100;//不要
        objHeight = 50;//不要

        // オブジェクトの座標を定義(キャンバスの中央に表示)
        objX = canvas.width / 2 - objWidth / 2;//不要
        objY = canvas.height / 2 - objHeight / 2;//不要

        // オブジェクトを描画
        drawRect();//不要
        }

        function drawRect() {
        context.fillRect(objX, objY, objWidth, objHeight);
        }

        var x, y, relX, relY;
        var dragging = false;

        function onDown(e) {
        // キャンバスの左上端の座標を取得
        var offsetX = canvas.getBoundingClientRect().left;
        var offsetY = canvas.getBoundingClientRect().top;

        // マウスが押された座標を取得
        x = e.clientX - offsetX;
        y = e.clientY - offsetY;

        // オブジェクト上の座標かどうかを判定
        if (objX < x && (objX + objWidth) > x && objY < y && (objY + objHeight) > y) {
            dragging = true; // ドラッグ開始
            relX = objX - x;
            relY = objY - y;
        }
        }

        canvas.addEventListener('mousedown', onDown, false);

        function onMove(e) {
  // キャンバスの左上端の座標を取得
var offsetX = canvas.getBoundingClientRect().left;
var offsetY = canvas.getBoundingClientRect().top;

  // マウスが移動した先の座標を取得
x = e.clientX - offsetX;
y = e.clientY - offsetY;

  // ドラッグが開始されていればオブジェクトの座標を更新して再描画
if (dragging) {
    objX = x + relX;
    objY = y + relY;
    drawRect();
}
}

function onUp(e) {
    dragging = false; // ドラッグ終了
}

function drawRect() {
    context.clearRect(0, 0, canvas.width, canvas.height); // キャンバスをクリア
    context.fillRect(objX, objY, objWidth, objHeight);
}

canvas.addEventListener('mousemove', onMove, false);
canvas.addEventListener('mouseup', onUp, false);